const express = require('express');
const serverless = require('serverless-http');

const app = express();
const router = express.Router();

function extractAndMerge(originalJson) {
    const result = {};
    
    originalJson.forEach(item => {
        const idStr = item.ename + '|';
        const typeStr = item.hero_type + (item.hero_type2 ? '|' : '');
        result[item.cname] = idStr + typeStr + (item.hero_type2 || '');
    });
    
    return result;
}

async function getHeros() {
    const url = 'https://pvp.qq.com/web201605/js/herolist.json';
    
    try {
        const response = await fetch(url, {
            headers: {
                'Origin': 'https://pvp.qq.com',
                'Referer': 'https://pvp.qq.com'
            }
        });
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const data = await response.json();
        return extractAndMerge(data);
    } catch (error) {
        console.error('Fetch error:', error);
        throw error;
    }
}

router.get('/getheros', async (req, res) => {
    try {
        const data = await getHeros();
        res.json(data);
    } catch (error) {
        res.status(500).json({ error: '服务器错误' });
    }
});

app.use((req, res, next) => {
    res.header('Content-Type', 'application/json;charset=utf-8');
    next();
});

app.use(router);

const server = app.listen(3000, () => {
    console.info('http://localhost:' + server.address().port);
});

module.exports.handler = serverless(app);